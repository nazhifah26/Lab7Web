<?php

// Inisialisasi routing
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// Mendapatkan peningkatan performa dengan menentukan default route
// sehingga tidak perlu scan direktori.
$routes->get('/about', 'Page::about');
$routes->get('/contact', 'Page::contact');
$routes->get('/faqs', 'Page::faqs');
$routes->get('/', 'Home::index');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 */

// Di bagian ini, Anda dapat menambahkan routing tambahan sesuai kebutuhan.
// Anda juga dapat meng-override pengaturan default di atas dengan
// menambahkan file routing tambahan jika diperlukan.
