<?= $this->include('template/admin_header'); ?>
<head>
    <meta charset="UTF-8">
    <title>Admin Portal Berita</title>
    <link rel="stylesheet" href="<?= base_url('css/style.css'); ?>">
</head>
<body>
    <h1>Admin Portal Berita</h1>
    <nav>
        <a href="<?= base_url('/admin/dashboard');?>" class="active">Dashboard</a>
        <a href="<?= base_url('/admin/artikel');?>">Artikel</a>
        <a href="<?= base_url('/admin/artikel/add');?>">Tambah Artikel</a>
    </nav>
<h2><?= $title; ?></h2>
<form action="" method="post">
<p>
<input type="text" name="judul" value="<?= $data['judul'];?>" >
</p>
<p>
<textarea name="isi" cols="50" rows="10"><?=
$data['isi'];?></textarea>
</p>
<p><input type="submit" value="Kirim" class="btn btn-large"></p>
</form>
<?= $this->include('template/admin_footer'); ?>